package com.zohocrm.util;

public interface EmailService {
	
	public void sendSimpleMail(String to, String sub, String emailBody);
	
}

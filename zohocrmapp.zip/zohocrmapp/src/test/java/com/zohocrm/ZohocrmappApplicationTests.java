package com.zohocrm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZohocrmappApplicationTests {

	@Test
	void contextLoads() {
	}

}
